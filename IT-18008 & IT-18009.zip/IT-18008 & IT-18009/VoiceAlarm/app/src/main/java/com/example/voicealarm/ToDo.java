package com.example.voicealarm;

import java.util.Date;

public class ToDo {
    private int id;
    private String message;
    private Date date;

    public ToDo() {
    }

    public ToDo(int id, String message, Date date) {
        this.id = id;
        this.message = message;
        this.date = date;
    }

    public void longToDate(long value) {
        date = new Date(value);
    }

    public long toLongValue() {
        return date.getTime();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "ToDo{" +
                "id=" + id +
                ", message='" + message + '\'' +
                ", date=" + date.toLocaleString() +
                '}';
    }
}
