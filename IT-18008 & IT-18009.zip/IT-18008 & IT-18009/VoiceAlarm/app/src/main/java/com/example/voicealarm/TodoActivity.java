package com.example.voicealarm;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TodoActivity extends AppCompatActivity {

    private final int REQ_CODE = 100;
    private final int INPUT_TIME = 0;
    private final int INPUT_DATE = 1;
    private final int INPUT_MESSAGE = 2;
    private int selectedVoiceInput = -1;

    private int hh = -1, mm = -1, xm = -1, DD = -1, MM = -1, YYYY = -1;
    private String message;

    private final List<String> monthNames = Arrays.asList(
            "january", "february", "march", "april", "may", "june", "july",
            "august", "september", "october", "november", "december"
    );

    private final String[] options = {
            "Speak Time Please",
            "Speak Date Please",
            "Speak Message Please"
    };

    private DataSource source;

    private TextView tvTime;
    private TextView tvAmpm;
    private TextView tvDate;
    private EditText tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);
        this.getSupportActionBar().setTitle("Add Todo");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        source = new DataSource(getApplicationContext());

        tvTime = findViewById(R.id.time);
        tvAmpm = findViewById(R.id.ampm);
        tvDate = findViewById(R.id.date);
        tvMessage = findViewById(R.id.message);
    }

    public void resetTime(View view) {
        tvTime.setText("hh : mm");
        tvAmpm.setText("xm");
        hh = mm = xm = -1;
    }

    public void voiceTime(View view) {
        voiceInput(INPUT_TIME);
    }

    public void resetDate(View view) {
        tvDate.setText("DD - MM - YYYY");
        DD = MM = YYYY = -1;
    }

    public void voiceDate(View view) {
        voiceInput(INPUT_DATE);
    }

    public void resetMessage(View view) {
        message = null;
        tvMessage.setText("");
    }

    public void voiceMessage(View view) {
        voiceInput(INPUT_MESSAGE);
    }

    public void voiceInput(int option){
        selectedVoiceInput = option;
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, options[option]);
        try {
            startActivityForResult(intent, REQ_CODE);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(), "Sorry your device not supported", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    Object voiceInput = result.get(0);
                    Toast.makeText(this, ""+result.get(0), Toast.LENGTH_LONG).show();
                    if (voiceInput != null) {
                        setVoiceInputToField(voiceInput.toString());
                    }
                }
                break;
            }
        }
    }

    public void setVoiceInputToField(String value) {
        switch (selectedVoiceInput) {
            case INPUT_TIME:
                convertVoiceToTime(value);
                break;
            case INPUT_DATE:
                convertVoiceToDate(value);
                break;
            case INPUT_MESSAGE:
                convertVoiceToMessage(value);
                break;
        }
    }

    public void convertVoiceToTime(String value) {
        final String REGEX = "(0?[1-9]|1[0-2]):([0-5]?\\d)\\s*([ap]\\.?m\\.?)";
        try {
            Pattern pattern = Pattern.compile(REGEX);
            Matcher matcher = pattern.matcher(value);
            if (matcher.matches()) {
                String time = "";
                hh = Integer.parseInt(matcher.group(1));
                mm = Integer.parseInt(matcher.group(2));
                time += hh + " : " + mm;
                String _xm = matcher.group(3);
                if ((_xm.startsWith("p") || _xm.startsWith("P")) && hh < 12) {
                    hh += 12;
                    tvAmpm.setText("pm");
                } else {
                    tvAmpm.setText("am");
                }
                tvTime.setText(time);
            } else {
                resetTime(null);
                alertSpeechNotRecognition(INPUT_TIME, "Error!", "Could not recognized time from your voice.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void convertVoiceToDate(String value) {
        final String REGEX = "(\\d{1,2})\\s*([a-zA-Z]{3,9})\\s*(\\d{4})";
        Pattern pattern = Pattern.compile(REGEX);
        Matcher matcher = pattern.matcher(value);
        System.out.println(matcher.matches());
        if (matcher.matches()) {
            DD = Integer.parseInt(matcher.group(1));
            String month = matcher.group(2).toLowerCase();
            if (monthNames.contains(month)) {
                MM = monthNames.indexOf(month);
                YYYY = Integer.parseInt(matcher.group(3));
                System.out.println(DD + "-" + MM + "-" + YYYY);
                Calendar calendar = Calendar.getInstance();
                calendar.set(YYYY, MM, DD);
                Date date = calendar.getTime();
                System.out.println(date.toLocaleString());
                System.out.println(date.getMonth() == MM);
                if (date.getMonth() == MM) {
                    tvDate.setText(DD + " - " + month + " - " + YYYY);
                } else {
                    resetDate(null);
                    alertSpeechNotRecognition(INPUT_DATE, "Error!",
                            "Could not recognized any valid date from your voice.");
                }
            } else {
                resetTime(null);
                alertSpeechNotRecognition(INPUT_DATE, "Error!",
                        "Could not recognized any valid date from your voice.");
            }
        }
    }

    public void convertVoiceToMessage(String value) {
        message = value;
        tvMessage.setText(message);
    }

    public void save(View view) {
        // Toast.makeText(getApplicationContext(), "hh:"+hh +"-mm:"+mm + "-xm:"+xm + ", DD:"+DD+"-MM:"+MM+"-YYYY:"+YYYY, Toast.LENGTH_LONG).show();
        if (hh == -1 || DD == -1 || message == null) {
            alert("Warning!", "Please enter valid data before save");
        } else {
            Calendar calendar = Calendar.getInstance();
            calendar.set(YYYY, MM, DD, hh, mm, 0);
            Date date = calendar.getTime();
            if (date.after(new Date())) {
                ToDo todo = new ToDo();
                todo.setMessage(message);
                todo.setDate(date);
                source.insert(todo);
                addToTodoListener(todo);
                resetTime(null);
                resetDate(null);
                resetMessage(null);
                alert("Success!", todo.toString() + "\n\nSuccessfully added.");
            } else {
                alert("Warning!", "Pleas enter future data and time before save todo");
            }
        }
    }

    public void addToTodoListener(ToDo todo) {
        Intent intent = new Intent(getApplicationContext(), TodoListener.class);
        intent.putExtra("date", todo.getDate().toLocaleString());
        intent.putExtra("message", todo.getMessage());
        Random r = new Random();

        PendingIntent sender = PendingIntent.getBroadcast(getApplicationContext(), r.nextInt(10000), intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager mAlarmManager = (AlarmManager)getApplication().getSystemService(getApplication().ALARM_SERVICE);
        mAlarmManager.setExact(AlarmManager.RTC_WAKEUP, todo.getDate().getTime(), sender);
    }

    public void alertSpeechNotRecognition(final int option, String title, String message) {
        AlertDialog.Builder alert = new AlertDialog.Builder(TodoActivity.this);
        alert.setTitle(title);
        alert.setMessage(message);
        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alert.setPositiveButton("Try again", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                voiceInput(option);
            }
        });
        alert.show();
    }

    public void alert(String title, String message) {
        AlertDialog.Builder alert = new AlertDialog.Builder(TodoActivity.this);
        alert.setTitle(title);
        alert.setMessage(message);
        alert.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alert.show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.onBackPressed();
        }
        return true;
    }

}