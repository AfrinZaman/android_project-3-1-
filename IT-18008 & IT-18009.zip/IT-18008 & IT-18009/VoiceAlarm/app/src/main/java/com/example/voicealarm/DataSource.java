package com.example.voicealarm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DataSource extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "voice_todo.db";
    public static final String TABLE_NAME = "todo";

    public DataSource(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    public void createTable() {

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("#### Create table......");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT, date NUMERIC)");
        System.out.println("# Successfully created...");
    }

    public void insert(ToDo todo) {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("message", todo.getMessage());
        contentValues.put("date", todo.toLongValue());
        //String sql = "insert into " + TABLE_NAME + "(message, date) values ('" + todo.getMessage() + "', " + todo.toLongValue() + ")";
        //database.execSQL(sql);
        database.insert(TABLE_NAME, null, contentValues);
    }

    public List<ToDo> fetch() {
        List<ToDo> todoList = new ArrayList<>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from " + TABLE_NAME + " order by date asc", null);
        while (cursor.moveToNext()) {
            ToDo todo = new ToDo();
            todo.setId(cursor.getInt(0));
            todo.setMessage(cursor.getString(1));
            todo.longToDate(cursor.getLong(2));
            todoList.add(todo);
        }
        return todoList;
    }

    public void delete(ToDo todo) {
        SQLiteDatabase database = getWritableDatabase();
        database.delete(TABLE_NAME, "id=" + todo.getId(), null);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
