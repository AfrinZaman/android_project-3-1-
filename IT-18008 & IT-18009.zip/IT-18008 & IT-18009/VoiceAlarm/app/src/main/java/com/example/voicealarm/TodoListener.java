package com.example.voicealarm;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.Random;

public class TodoListener extends BroadcastReceiver {

    private NotificationManagerCompat notificationManagerCompat;

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        notificationManagerCompat = NotificationManagerCompat.from(context);
        System.out.println("### Alarm : " + bundle.getString("date") + ", " + bundle.getString("message"));
        Toast.makeText(context, "### Alarm : " + bundle.getString("date") + ", " + bundle.getString("message"), Toast.LENGTH_SHORT).show();
        addNotification(bundle.getString("message"), context);
    }

    private void addNotification(String message, Context context) {
        String title = "Voice Todo";
        Notification notification = new NotificationCompat.Builder(context, NotificationApp.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_baseline_message_24)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

        Random random = new Random();
        int notificationId = random.nextInt(1000);
        this.notificationManagerCompat.notify(notificationId, notification);
    }


}
