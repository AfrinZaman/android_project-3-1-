package com.example.voicealarm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class TodoListAdapter extends ArrayAdapter<ToDo> {

    private Context context;
    private List<ToDo> todoList;

    public TodoListAdapter(@NonNull Context context, @NonNull List<ToDo> todoList) {
        super(context, R.layout.todo_item, todoList);
        this.context = context;
        this.todoList = todoList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.todo_item, null,true);
        TextView etDate = view.findViewById(R.id.dateTime);
        TextView etMessage = view.findViewById(R.id.message);
        ToDo todo = todoList.get(position);
        etDate.setText(todo.getDate().toLocaleString());
        etMessage.setText(todo.getMessage());
        return view;
    }
}
